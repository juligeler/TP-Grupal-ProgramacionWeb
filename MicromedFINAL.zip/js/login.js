function validateForm() {
    var username = document.getElementById('username').value;
    var password = document.getElementById('password').value;

    if (username === 'Micromed' && password === 'user123') {
        return true;
    } else {
        alert('Credenciales incorrectas');
        return false;
    }
}
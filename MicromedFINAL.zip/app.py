from flask import Flask, render_template, request, redirect, url_for, jsonify

app = Flask(__name__)

# Lista de productos (simulación de una base de datos)
products = [
    {'id': 1, 'name': 'Canu Mic', 'price': 79.999, 'stock': 100, 'image_url': 'https://www.micromedsystem.com/images/productos/cadera-canu-mic-mini.jpg'},
    {'id': 2, 'name': 'Fic Mic', 'price': 9.999, 'stock': 50, 'image_url': 'https://www.micromedsystem.com/images/productos/rodilla-fix-mic-mini.jpg'},
    {'id': 3, 'name': 'Endomic Max', 'stock': 200, 'price': 14.999, 'image_url': 'https://www.micromedsystem.com/images/productos/hombro-endomic-max-mini.jpg'},
    {'id': 4, 'name': 'Foot Mic', 'stock': 75, 'price': 15.999, 'image_url': 'https://www.micromedsystem.com/images/productos/pierna-tobillo-pie-foot-mic-mini.jpg'},
    {'id': 5, 'name': 'Grapa Tipo Iql', 'stock': 120, 'price': 9.999, 'image_url': 'https://www.micromedsystem.com/images/productos/rodilla-grapa-tipo-iql-mini.jpg'},
    {'id': 6, 'name': 'Her Mic', 'stock': 150, 'price': 49.999, 'image_url': 'https://www.micromedsystem.com/images/productos/mano-muneca-her-mic-mini.jpg'},
    {'id': 7, 'name': 'Micro Radius', 'stock': 30, 'price': 99.999, 'image_url': 'https://www.micromedsystem.com/images/productos/mano-muneca-microradius-mini.jpg'},
    {'id': 8, 'name': 'Micro Placa', 'stock': 25, 'price': 40.999, 'image_url': 'https://www.micromedsystem.com/images/productos/mano-muneca-microplacas-mini.jpg'},
    {'id': 9, 'name': 'Smart Fusion Peel', 'stock': 60, 'price': 10.999, 'image_url': 'https://www.micromedsystem.com/images/productos/craneo-smart-fusion-peek-mini.jpg'},
    {'id': 10, 'name': 'Rc Peek', 'stock': 80, 'price': 3.999, 'image_url': 'https://www.micromedsystem.com/images/productos/rodilla-rc-peek-mini.jpg'}
    
]


@app.route('/')
def inicio():
    return render_template('inicio.html')

@app.route('/login')
def login():
    return render_template('login.html')

@app.route('/login', methods=['POST'])
def loguear():
    username = request.form['username']
    password = request.form['password']

    # Verifica las credenciales (en este ejemplo, usuario y contraseña hardcoded)
    if username == 'Micromed' and password == 'user123':
        return redirect(url_for('carrito'))
    else:
        return render_template('login.html', message='Credenciales incorrectas')
    

@app.route('/contacto')
def contacto():
    return render_template('contacto.html')

@app.route('/consultas')
def consultas():
    return render_template('consultas.html')

@app.route('/sobre_nosotros')
def sobre_nosotros():
    return render_template('sobre_nosotros.html')

@app.route('/agradecimiento')
def agradecimiento():
    return render_template('agradecimiento.html')

@app.route('/productos')
def productos():
    return render_template('productos.html', products=products)


@app.route('/carrito')
def carrito():
    return render_template('carrito.html', products=products)

@app.route('/get_product/<int:product_id>', methods=['GET'])
def get_product(product_id):
    product = next((product for product in products if product["id"] == product_id), None)
    if product:
        return render_template('product_detail.html', product=product)
    else:
        return jsonify({'error': 'Producto no encontrado'})


@app.route('/add_product', methods=['GET', 'POST'])
def add_product():
    if request.method == 'POST':
        name = request.form['name']
        price = float(request.form['price'])
        stock = int(request.form['stock'])
        image_url = request.form.get('image_url')
        
        # Crea el nuevo producto con la información que recopilaste
        new_id = max(product["id"] for product in products) + 1
        new_product = {
            "id": new_id,
            "name": name,
            "price": price,
            "stock": stock,
            "image_url": image_url
        }
        products.append(new_product)
        return redirect(url_for('carrito'))
    
    return render_template('add_product.html')

# Ruta para editar un producto (formulario)
@app.route('/edit_product/<int:product_id>', methods=['GET', 'POST'])
def edit_product(product_id):
    product_to_edit = next((product for product in products if product["id"] == product_id), None)
    if request.method == 'POST' and product_to_edit:
        product_to_edit["name"] = request.form['name']
        product_to_edit["price"] = float(request.form['price'])
        product_to_edit["stock"] = int(request.form['stock'])
        return redirect(url_for('carrito'))
    return render_template('edit_product.html', product=product_to_edit)

# Ruta para eliminar un producto
@app.route('/delete_product/<int:product_id>')
def delete_product(product_id):
    global products
    products = [product for product in products if product["id"] != product_id]
    return redirect(url_for('carrito'))

if __name__ == '__main__':
    app.run(debug=True)